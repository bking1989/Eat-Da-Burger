var orm = require("../config/orm.js");

var burger = {
    all: () => {
        orm.all();
    },

    create: () => {
        orm.insertOne();
    },

    update: () => {
        orm.updateOne();
    },

    select: () => {
        orm.selectAll();
    },
};

module.exports = burger;