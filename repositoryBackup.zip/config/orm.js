var connection = require("./connection.js");

var orm = {
    selectAll: () => {},
    insertOne: () => {},
    updateOne: () => {}
};

module.exports = orm;