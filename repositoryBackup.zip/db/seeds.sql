INSERT INTO burgers(burger_name, devoured) VALUES("Hawaiian Burger", 0);
INSERT INTO burgers(burger_name, devoured) VALUES("Western Bacon Cheeseburger", 0);
INSERT INTO burgers(burger_name, devoured) VALUES("Grilled Chicken Burger", 0);